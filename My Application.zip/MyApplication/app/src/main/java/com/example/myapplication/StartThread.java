package com.example.myapplication;

import android.content.Intent;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.os.Handler;

public class StartThread extends Thread{
    private  Handler handler;
    public StartThread(Handler handler){
        this.handler = handler;
    }
    @Override
    public void run(){
        Message msg = new Message();
        try{
            Thread.sleep(3000);
            msg.what = 1;
            handler.sendEmptyMessage(msg.what);
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
