package com.example.please_button;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.content.Intent;

import android.widget.Button;

import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    Button motorBtn, linearBtn, cameraBtn, operateBtn;

    Socket socket = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setElevation(0);

        linearBtn = (Button) findViewById(R.id.btn_l);
        motorBtn= (Button) findViewById(R.id.btn_m);
        cameraBtn = (Button) findViewById(R.id.btn_camera);
        operateBtn = (Button) findViewById(R.id.btn_operate);

        linearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MotorActivity.class);
                startActivity(intent);
            }
        });

        motorBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LinearActivity.class);
                startActivity(intent);
            }
        });

        cameraBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CameraActivity.class);
                startActivity(intent);
            }
        });

        operateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), OperateActivity.class);
                startActivity(intent);
            }
        });
    }
}