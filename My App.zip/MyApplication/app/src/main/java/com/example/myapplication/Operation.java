package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Button;


//public class Operation {
//}
public class Operation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.operation);

        ImageButton home_btn = findViewById(R.id.home_button);
        home_btn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });

        ImageButton back_btn = findViewById(R.id.back_button);
        back_btn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });

        Button next_btn = findViewById(R.id.next_button);
        next_btn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Operation_next.class);
            startActivity(intent);
        });

//        Button high_btn = findViewById(R.id.high_button);
//        high_btn.setOnClickListener(view -> {
//            Intent intent = new Intent(getApplicationContext(), Operation.class); // 윤아 코드
//            startActivity(intent);
//        });
    }
}
