package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    EditText id, pw;
//    CheckBox check;
//    boolean loginChecked;
//    SharedPreferences pref;
//    SharedPreferences.Editor editor;
//@Nullable
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        String id_input = id.getText().toString();
        String pw_input = pw.getText().toString();
        if (id_input == "o1a4" && pw_input == "1234") {
            Toast.makeText(Login.this, "Login Success", Toast.LENGTH_SHORT).show();
            Button login_btn = findViewById(R.id.login_button);
            login_btn.setOnClickListener(view -> {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            });
        }
        else{
            Toast.makeText(Login.this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
}
}

//        setContentView(R.layout.activity_login);
//        id = findViewById(R.id.id);
//        pw = findViewById(R.id.Password);
//        check = findViewById(R.id.checkBox);
//
//        if(pref.getBoolean("check",false)){
//            id.setText(pref.getString("id", ""));
//            check.setChecked(true);
//        }
//        else {
//            String id_input = id.getText().toString();
//            String pw_input = pw.getText().toString();
//            if(id_input == "o1a4" && pw_input == "1234"){
//                Toast.makeText(Login.this, "Login Success", Toast.LENGTH_SHORT).show();
//                Button login_btn = findViewById(R.id.login_button);
//                login_btn.setOnClickListener(view -> {
//                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
//                    startActivity(intent);
//                });
//            }
//            Boolean validation = loginValidation(id_input,pw_input);
//            if(validation){
//                Toast.makeText(Login.this, "Login Success", Toast.LENGTH_SHORT).show();
//                if(loginChecked){
//                    editor.putString("id",id_input);
//                    editor.putString("pw",pw_input);
//                    editor.putBoolean("auto",true);
//                    editor.commit();
//                }
//                else {
//                    Toast.makeText(Login.this,"Login Failed",Toast.LENGTH_SHORT).show();
//                }
//            }
//            check.setOnCheckedChangeListener((buttonView, isChecked) -> {
//                if(isChecked) {
//                    loginChecked = true;
//                } else {
//                    // if unChecked, removeAll
//                    loginChecked = false;
//                    editor.clear();
//                    editor.commit();
//                }
//            });
//        }
//    }
//    private boolean loginValidation(String id, String password) {
//        if(pref.getString("id","").equals(id) && pref.getString("pw","").equals(password)) {
//            // login success
//            return true;
//        } else if (pref.getString("id","").equals(null)){
//            // sign in first
//            Toast.makeText(Login.this, "Please Sign in first", Toast.LENGTH_LONG).show();
//            return false;
//        } else {
//            // login failed
//            return false;
//        }
//    }
//}
